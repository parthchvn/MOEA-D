# Research status

Last structured audit: 2026-11-02.

## Active broadcast ablation (2026-11-03 02:38 UTC)

The new user-authorized study compares only lazy q=1/2 broadcast ON/OFF,
refining the earlier three-arm proposal before outcomes. Activation 02:28:31
UTC, experiment-start cutoff 03:58:31, hard deadline 04:28:31. Baseline 37 tests
and compilation passed; exact pre-edit dirty source is preserved under
`research/runs/20261103T022831Z-broadcast-baseline/`.
Independent pre-change constraints preceded edits. Implementation now preserves
legacy defaults while adding the broadcast intervention, confirmed passive phase
times, explicit paired blocks and missing-block-aware analysis; 54 tests pass.
No recorded grid has started; evaluator implementation review is the next gate.
See `BROADCAST_PREREG.md`. Prior factorial data/report/preregistration remain
unchanged. No new operator, q, scheduler, noise study, or asymptotic claim is made.

## Controlled study completed (2026-11-02 21:55:28 UTC)

**Mechanically checked:** baseline 16 tests and compilation passed on clean
HEAD `7c4e8addcca6adf04d65f74fec05244bbb26ab5f`. A five-hour study started at
21:27:58 UTC; experiment-start cutoff is 2026-11-03 01:42:58 UTC and final
deadline 02:27:58 UTC. Independent evaluator and literature audits preceded
builder edits. Independent evaluator approval gated smoke, main, and validation.
All 774 trajectories completed without censoring: 54 smoke (0.687 s), 576 main
(206.143 s), and 144 n=512 validation (695.881 s). Sources, seeds, balance and
endpoint invariants passed. The independent evaluator approved the finished
bundle at 21:55:13 UTC: all 37 tests passed independently, four modules compiled,
825 numerical checks matched separate raw-data recomputation, and core source/
snapshot/PDF/HEAD checks passed. The literature reviewer approved source/proof
scope, relying on the cited endpoint lemma externally. The report was completed
27 minutes 30 seconds after activation; no further experiment is needed for
this bounded goal. See `FACTORIAL_PREREG.md` and
`reports/20261102T212758Z-radius-factorial.md`.

**Empirically supported:** the preregistered decision favors the mutation-rule
change as the explanation of radius sensitivity. At primary n=256,
`R_exact=1.582`, `R_lazy=1.162`, mutation attenuation `M=0.309` with pointwise
95% bootstrap `[0.057,0.574]`; n=512 validation gives `M=0.314`,
`[0.026,0.610]`. Smaller n=32/64/128 remain inconclusive. Lazy mutation is slower
in raw evaluations at the primary positive radii; the finding concerns radius
sensitivity, not an overall speedup. All 480 main/validation positive-radius
trajectories had equal sampled endpoints, while r=0 had substantial gaps.

**Contradicted:** universal positive-radius event equality. A feasible n=3,r=1
path from `[1,1,1,2]` reaches archive coverage at evaluation 8 and alignment at
10. Zero-gap empirical bootstrap intervals therefore do not bound rare gaps.
The same path refutes a universal endpoint-last-hit/alignment identity (C10),
while leaving asymptotic endpoint dominance unresolved.

**Proved (source-based inference, not the printed theorem event):** the paper's
type-A upper-bound argument for r>=1 solves all subproblems, so the lack of alignment in
its stated archive stopping event does not itself prevent its expectation upper
argument from applying to the lazy controlled comparator. No tail or lazy
lower bound is transferred. Full source reconciliation is recorded in
`PAPER_COMPARISON.md`.

## Current state

- The repository has the legacy noisy and noiseless models, an exploratory
  notebook, and the canonical exact/lazy paired-event controlled variant.
- Basic noiseless properties pass small finite checks: unique scalarization minimizers, reciprocal radius neighborhoods, deterministic seeded runs, and convergence on a smoke set.
- The included noisy `T=1` draft is not yet a complete proof. The most important gap is conditioning on accepted stored noisy values.
- The larger-neighborhood runtime law is a well-formed conjecture with suggestive simulations, but no proof document is present.
- A preprint posted on 2026-10-26 directly studies MOEA/D solution exchange on OneMinMax. It proves `Theta(n^2)` evaluations for every communication radius `r >= 1` and `Theta(n^2 log n)` for `r = 0` in its model. This is in tension with the repository's claimed logarithmic threshold.
- The most important identified model difference is mutation: the preprint's quadratic upper-bound class requires a constant probability of producing a same-Hamming-weight offspring, while exact one-bit mutation always changes the Hamming weight by one. This is a sufficient-condition gap, not evidence by itself of a slower runtime. The preprint also measures archive coverage, while `large.py` waits for simultaneous subproblem alignment.
- The whole-process invariant `(J)` is contradicted at initialization. The code's checks after sweep 2 concern only a possible post-burn-in property.
- The recorded-run harness now checkpoints after every trial, enforces separate per-trial and total deadlines, uses balanced round-robin configuration order, and snapshots source files and dependency versions.
- There was previously no environment specification, test suite, experiment manifest, claim ledger, or long-run protocol.

## Best next bounded question

The post-study independent synthesis is saved in `NEXT_DIRECTIONS.md`.
The evaluator approved its proposed design and C16 argument; the literature
reviewer approved its primary-source assumptions and citations. It remains a
reviewed proposal, not an executed study.
**Proposed, not preregistered or launched:** first compare fresh exact mutation
with lazy-1/2 broadcast ON/OFF, adding passive target/endpoint/interior phase
times. Proposed smoke has 54 trajectories, n=256 primary 288, and timing-gated
n=512 validation 144; large r=0 cells are omitted because r=0 is a pathwise
ON/OFF identity control. Require both useful r=1 broadcast and a radius
interaction, not an interaction alone. A two-hour ceiling is a planning
suggestion, not authorization. No new implementation or experiment occurred.

**Proved alternate-process control (C16):** independent uniform breeders with
lazy broadcast OFF permit deletion of inert holds, giving the exact embedded
chain and a 1/(1-q) expected offspring-count factor. This process is not
implemented and the identity does not transfer to cyclic breeders. Existing
empirical claim statuses are unchanged. Next priorities are the standard-bit
bridge, then outcome-dependent dose/scheduler or finite-state analysis; weighted
or dynamic decomposition and noise are separate later projects.

**Conjectured:** useful same-weight neighbor broadcast directly causes the
attenuation. Isolate it with a new preregistered lazy-1/2 ablation suppressing
only neighbor replacement on self-loop offspring, retaining offspring
generation/evaluation, passive archive, breeder self-comparison, cyclic order,
moving-offspring communication, and paired random streams. This would separate
broadcast effects from reduced moving frequency/cyclic retiming. It was not run
in this goal. Exact one-bit asymptotics and C3/C4 remain open conjectures.

## Resolved model-comparison checklist

The completed comparison with Doerr, Elmoutassim, Krejca, and Kibulu (2026)
records these distinctions in `PAPER_COMPARISON.md`:

1. archive coverage versus simultaneous exact subproblem alignment;
2. one-bit versus standard-bit or general mutation;
3. uniform versus cyclical breeder selection and the repository's sweep update order;
4. whether offspring are communicated after acceptance only or offered independently to all neighbors;
5. radius and boundary conventions;
6. tie acceptance, reference point, scalarization orientation, and initialization.
7. self-parent mutation in `large.py` versus neighborhood-parent selection in `sim.py`.

The models differ. The controlled study isolates mutation and stopping as two
factors; it supports C13 in the tested finite range without retiring or proving
the exact-one-bit asymptotic conjectures. The study remains noiseless.

## Exploratory radius diagnostic

An uncommitted, machine-recorded smoke grid used `n in {50,100,200}`, `r in {0,1,4}`, and eight independent repetitions per configuration. It had no censoring. Mean sweeps for `r=1` were `94.6`, `175.3`, and `526.1`; for `r=4` they were `65.4`, `131.8`, and `382.6`. This confirms a finite-size benefit from communication and from increasing the radius, but the range and variance are far too small to distinguish linear from `n log n` behavior. The run is stored locally under `research/runs/20261102T204129Z-large-grid-radius-diagnostic/` and is intentionally ignored by Git.

## Suggested bounded work packages

### A. Canonical-model reconciliation — completed

The source-cited comparison, model conventions, index/complement transformations,
clipped endpoint neighborhoods and both event definitions are recorded in
`PAPER_COMPARISON.md`, `PROJECT.md`, and `FACTORIAL_PREREG.md`. The controlled
implementation and tests match this freeze. The next empirical task is the
self-loop broadcast ablation above, not repeating model reconciliation.

### B. Noisy drift audit

- Enumerate the augmented state `(true weight, stored value)` for one extreme subproblem.
- Derive exact transition probabilities including acceptance.
- Compute conditional drift for every reachable state for small `n` and symbolic `p` where feasible.
- Test whether a one-dimensional potential can work; otherwise design a phase or two-dimensional potential.

### C. Noiseless neighborhood theorem

- If useful, formulate and test a new post-burn-in replacement for the contradicted whole-process invariant `(J)`.
- Separate endpoint hitting time, interior alignment, and simultaneous completion.
- Define effective neighborhood size by radius or minimum cardinality before stating asymptotics.
- Preregister scaling grids that discriminate candidate laws.

## Decision rule

Do not begin the noisy `T > 1` theorem until A is complete and the overlap with the October 2026 result is understood. Exploratory experiments are allowed when they directly distinguish the two processes or choose between proof strategies.

## Morning-report template

- Question attempted:
- Result and status label:
- Evidence produced:
- Counterexamples or failed approaches:
- Files changed:
- Commands/runs and elapsed time:
- Cloud cost, if any:
- Remaining uncertainty:
- Best next action:
