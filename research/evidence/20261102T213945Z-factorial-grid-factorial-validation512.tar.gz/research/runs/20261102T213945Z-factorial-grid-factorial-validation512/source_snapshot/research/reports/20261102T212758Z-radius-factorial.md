# Finite-size communication-radius study

Activated **2026-11-02 21:27:58 UTC**. Report in progress; outcomes below are
explicitly provisional until the final independent evaluator verdict.
Experiment-start cutoff: **2026-11-03 01:42:58 UTC**. Hard deadline:
**2026-11-03 02:27:58 UTC**. No cloud resources, costs, commits, pushes, source
PDF changes, or noisy-proof work are authorized or used.

## Question and controlled model

Does same-Hamming-weight offspring availability or archive-versus-alignment
stopping better explain finite-size radius sensitivity? The frozen protocol is
[`FACTORIAL_PREREG.md`](../FACTORIAL_PREREG.md); the source-cited model table,
apparent printed min/max typo, order-preserving genotype-complement conjugacy,
and theorem-transfer limitations are in
[`PAPER_COMPARISON.md`](../PAPER_COMPARISON.md).

The 2×2 compares exact versus lazy one-bit mutation (self-loop probability 1/2)
and passive archive coverage versus simultaneous exact alignment. Both stopping
times are observed on each trajectory and analyzed as paired endpoints. All
other process conventions and random-stream policies are fixed. This comparator
also halves moving mutations and is not standard bit mutation; radius-zero
results and radius-sensitivity contrasts account for that interpretive limit.

## Audit and reproducibility record

**Mechanically checked:** baseline HEAD
`7c4e8addcca6adf04d65f74fec05244bbb26ab5f`, clean status, 16 unit tests and
required compilation passed. Both reviewers supplied independent constraints
before builder edits. The builder alone wrote code/notes and launched grids.
Coordinator, evaluator and literature reviewer remained read-only.

**Contradicted intermediate implementation:** the first deadline implementation
used executed evaluations as a right-censor observation bound after an offspring
crossed the wall deadline. The evaluator and coordinator independently identified
that an unrecorded event could already have happened within that count. Before
any grid, the builder separated executed work from the confirmed observation
prefix. Late initialization has confirmed count zero; late offspring retain the
previous confirmed prefix; an earlier archive event survives later alignment
censoring. Added regression tests passed. A new slow-initialization fixture first
failed because its mock did not accept a keyword argument; the fixture was fixed
without weakening its assertion. These are implementation corrections, not
failed scientific hypotheses.

**Mechanically checked:** 36 tests and compilation passed before smoke; the
independent evaluator reran all 36 and explicitly approved smoke. The source
snapshot includes untracked/dirty code and notes with SHA-256 hashes; manifests
include all installed distribution versions, command, seed base, Git state,
deadline, runtime, and full parameters. Atomic results checkpoint after every
completed trajectory. A persisted-file interruption regression test verifies
that an interrupted next trial preserves its predecessor.

## Commands and scale decisions

Smoke command:

```bash
python scripts/run_research.py factorial-grid --n 8 16 32 --reps 3 --seed 2611021000 --max-evaluations 2000000 --max-trial-seconds 10 --max-seconds 300 --not-after-utc 2026-11-03T01:42:58Z --label factorial-smoke
```

Local ignored raw evidence:
`research/runs/20261102T213431Z-factorial-grid-factorial-smoke/`.
**Mechanically checked:** 54/54 trajectories; 18 cells with three repetitions
each; no endpoint censoring; complete manifest; all 26 snapshot hashes match;
all seeds unique and sequential; initialization ≤ archive ≤ alignment = executed
= confirmed observations; final archive and aligned counts equal n+1.
Elapsed runner time 0.687 s, maximum trajectory time 0.0475 s.

Twice the n² extrapolation from the n=32 smoke trial time projects 321 seconds
for the full preregistered main grid, comfortably below its 5,400-second cap.
This is a runtime budgeting estimate, not a claim about optimization complexity.
Smoke is excluded from the main inferential estimates. The 36 positive-radius
smoke trajectories had equal endpoint times; this descriptive observation alone
does not prove event equality.

The independent evaluator then approved exactly the preregistered main grid.

```bash
python scripts/run_research.py factorial-grid --n 32 64 128 256 --reps 24 --seed 2611022000 --max-evaluations 20000000 --max-trial-seconds 60 --max-seconds 5400 --not-after-utc 2026-11-03T01:42:58Z --label factorial-main
```

Raw evidence: `research/runs/20261102T213520Z-factorial-grid-factorial-main/`.
**Mechanically checked:** all 576 trajectories completed, each of 24 cells has
24 repetitions, no endpoint censoring, all 27 snapshot hashes match, seeds are
unique `2611022000..2611022575`, and all endpoint/count invariants hold. Elapsed
206.143 s, maximum trial 5.389 s. The n=256 trials used 157.897 s and total
non-trial overhead was 3.415 s.

The preregistered optional n=512 timing estimate is
`2*4*157.897 + 3.415/4 = 1264.03 seconds`, below its 4,500-second cap and the
remaining experiment window. This eligibility decision uses only timing,
censoring, and integrity; no bootstrap mechanism estimates had been computed
when eligibility was submitted for independent approval.

Validation outcomes, distributions, uncertainty, final claims, and independent
verdict will be added after their gates pass.
