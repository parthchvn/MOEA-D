# Lazy same-weight neighbor-broadcast ablation

Activated **2026-11-03 02:28:31 UTC**. New-study experiment-start cutoff:
**03:58:31 UTC**; hard deadline **04:28:31 UTC**. This report is in progress;
the final result requires independent review. All computation is local, cloud
spend $0; model/API billing is unmeasured. No commits, pushes, PDF changes,
RunPod, new mutation operator, scheduler, q value, or noisy-proof work.

## Question and controlled change

At fixed lazy one-bit q=1/2, does broadcasting same-weight offspring to other
subproblems help r=1 and contribute to finite radius attenuation? ON broadcasts
normally. OFF suppresses only j≠breeder replacement when offspring weight equals
its current breeder's parent weight. Evaluation, archive processing, self-
comparison, moving-offspring communication, initialization, scalarization, ties,
radius and cyclic visits remain fixed. The new two-arm request refines the
earlier three-arm roadmap before outcomes; no fresh exact arm is run.

The [frozen preregistration](../BROADCAST_PREREG.md) specifies paired blocks,
phase observations, missing/censor rules, seeds, caps and statistical policy.
The [canonical source comparison](../PAPER_COMPARISON.md) remains applicable.
OFF changes Algorithm 1's replacement rule, so the paper's type-A conditions
alone do not transfer its upper bound to OFF. C16's uniform-scheduler identity
also does not apply. This estimates a finite broadcast-policy effect, not a
natural-mediation fraction of the earlier exact-to-lazy contrast.

## Baseline, implementation and independent gates

**Mechanically checked:** baseline HEAD
`7c4e8addcca6adf04d65f74fec05244bbb26ab5f` is unchanged, with prior-study dirty
files preserved. Before edits, all 37 tests passed (0.674 s) and four modules
compiled. Exact dirty source/patch/status/dependencies are archived under
`research/runs/20261103T022831Z-broadcast-baseline/` (28 files).

The initial baseline command used the configured base Python and encountered
an unwritable Matplotlib cache warning; explicit `.venv/bin/python` and workspace
cache paths resolved this. The first baseline-manifest helper invocation used
a relative output path and failed before writing its manifest; rerunning with
the absolute path succeeded before implementation. No trial data were involved.

The builder alone edits and launches grids. Coordinator and reviewers remain
read-only. Independent pre-change audits preceded implementation. Optional core
flags preserve the old default API/seeded results while adding the broadcast
mask and passive confirmed-prefix first-hit phases. A new runner mode declares
every planned block/arm before execution and checkpoints each arm, including
partial-block/interruption cases. The separate analyzer retains all planned
blocks and jointly resamples arm/endpoint pairs. Arm order alternates by
repetition parity within each radius, rather than global block parity.

**Mechanically checked:** all 54 tests passed (builder 0.886 s; independent
evaluator 0.921 s), five modules compiled, whitespace checks passed. Tests include
legacy golden output, ON/OFF r=0/moving-only identity, useful ON copies, suppressed
OFF effects, observer passivity, deadline-confirmed phase hits, persisted
checkpoint/plan/source hashes, and missing/censored-block inference.
The evaluator approved smoke after reviewing code and the preregistration frozen
at **02:40:40 UTC**.

## Commands, timing and integrity

All experiment commands use `MPLCONFIGDIR=.cache/matplotlib XDG_CACHE_HOME=.cache`.
The workspace cache directories are ignored and excluded from source snapshots.

```bash
MPLCONFIGDIR=.cache/matplotlib XDG_CACHE_HOME=.cache .venv/bin/python scripts/run_research.py broadcast-grid --n 8 32 --include-zero --blocks 3 --seed 2611031000 --max-evaluations 2000000 --max-trial-seconds 10 --max-seconds 300 --not-after-utc 2026-11-03T03:58:31Z --label broadcast-smoke
```

Smoke evidence: `research/runs/20261103T024139Z-broadcast-grid-broadcast-smoke/`.
**Mechanically checked:** 36 trajectories, all 18 planned blocks complete,
zero censoring, 31 source hashes verified; all phase/count/seed/order invariants
hold. All six radius-zero block pairs match exactly apart from execution/arm
metadata. OFF hold-induced recipient changes/target acquisitions are zero.
Elapsed 0.9915 s; max trial 0.05955 s. Positive-radius n=32 trial time was
0.192639 s, giving the frozen conservative main prediction 394.525 s, below
its 2,700-second cap. This is a compute-budget projection, not a complexity law.

Main/validation evidence and the final independent verdict will be added only
after the relevant gates complete. Smoke is excluded from primary inference.
